<ul id="lightSlider" class="gallery list-unstyled cS-hidden">
    <li data-thumb="{{URL::to('/themes/clinic_simple')}}/images/content-img.jpg">
        <img src="{{URL::to('/themes/clinic_simple')}}/images/content-img.jpg" />
    </li>
    <li data-thumb="{{URL::to('/themes/clinic_simple')}}/images/content-img.jpg">
        <img src="{{URL::to('/themes/clinic_simple')}}/images/content-img.jpg" />
    </li>
    <li data-thumb="{{URL::to('/themes/clinic_simple')}}/images/content-img.jpg">
        <img src="{{URL::to('/themes/clinic_simple')}}/images/content-img.jpg" />
    </li>
</ul>