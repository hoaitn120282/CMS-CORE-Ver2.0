<div class="form-group">
    <input id="title"  name="title" value="{{ $options['title'] }}" class="form-control" type="hidden"/>
</div>


<div class="fieldset-content">
    <div class="form-group">
         @include("widgets.{$theme}.{$widget}.partials.input_upload", [
           'idModal'=> $options['baseID'],
            'model' => $options['slide_image'],
            'label' => 'Images',
            'input'=>'slide_image'
        ])
    </div>
    <div class="form-group">
        <label for="title" class="control-label">Title</label>
        <input class="form-control" name="slide_title" value="{{ $options['slide_title'] }}"/>
    </div>
    <div class="form-group">
        <label for="description" class="control-label">Description</label>
        <textarea id="description" class="form-control" 
        name="description" rows="3">{{ $options['slide_description'] }}</textarea>
    </div>
</div>
