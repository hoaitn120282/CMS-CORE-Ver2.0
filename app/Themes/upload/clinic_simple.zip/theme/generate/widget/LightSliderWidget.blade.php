

namespace {!!"App\\Widgets\\{$theme}"!!};

use App\Widgets\BaseWidget;

class {!!"{$widget}"!!} extends BaseWidget
{
    public function __construct() {
        $this->name = "Light Slider Widget";
        $this->description = 'This widget for light slider';
        $this->options = [
            "slide_image" => "",
            "slide_title" => "",
            "slide_description" => "",
            ];
    }

    public function form(){
        return \View::make('widgets.{!! $theme !!}.{!! $widget !!}.form',['options'=>$this->options, 'theme'=>"{!! $theme !!}", 'widget'=>"{!! $widget !!}"])->render();
    }

    public function run(){
        return \View::make('widgets.{!! $theme !!}.{!! $widget !!}.run',['options'=>$this->options])->render();
    }
}