.header{
	margin-bottom: 50px;

	& .header-contact{
		padding: 7px 0;
		background-color: {{ $css['simple_bg_contact_top_color'] }};

		& p, & li{
		color: {{ $css['simple_color_text_contact_top'] }};
		font-family: {{ $css['simple_font_bold'] }};
		}

		& li{
			margin-left: 20px;
		}
	}

	& .navbar{
		margin: 0;
		padding-top: 15px;
		padding-bottom: 15px;

		& .navbar-brand{
			padding: 10px 15px;
		}

		& .nav-right-custom{
			& li{
				margin-left: 30px;
				& a{
					text-transform: uppercase;
					font-family: {{ $css['simple_font_black'] }};
					font-size: 16px;
					color: {{ $css['simple_font_black'] }};

					&:focus, &:hover, &.active {
						background: none;
						color: {{ $css['simple_menu_hover_cl'] }};
					}
				}
			}

			& .language-select{
				& i{
					margin-left: 10px;
				}

				&>a{
					padding-left: 0;
				}
				& a{
					font-size: 14px;
					font-family: "Raleway-Medium";
					text-transform: inherit;
				}

				& ul{
					left: 0;
					right: auto;
					margin-top: 15px;
					border: none;
					border-radius: 0;

					& li{
						margin:15px 0 15px 0;
						text-align: left;
					}
				}
			}
			
		}
	}

	.nav .open>a, .nav .open>a:focus, .nav .open>a:hover{
		background: transparent;
	}
}


@media (max-width: 769px) {
	.navbar-header {
    	float: none;
	}
	.navbar-left,.navbar-right {
	    float: none !important;
	}
	.navbar-toggle {
	   display: block;
	   margin-right: 0;
 	}
 	.navbar-collapse {
	    border-top: 1px solid transparent;
	    box-shadow: inset 0 1px 0 rgba(255,255,255,0.1);
	}
	.navbar-fixed-top {
	    top: 0;
	    border-width: 0 0 1px;
	}
 	.navbar-collapse.collapse {
     	display: none!important;
	}
	.navbar-nav {
	    float: none!important;
	    margin-top: 7.5px;
	}
	.navbar-nav>li {
	    float: none;
	}
	.navbar-nav>li>a {
	    padding-top: 10px;
	    padding-bottom: 10px;
	}
	.collapse.in{
	    display:block !important;
	}
		
	.navbar{
		& .icon-bar{
		  	background-color: #222222;
		  	height: 3px;
		  	width: 30px;
		}		
	}

	.header{
		& .header-contact{
			& p, & li{
				font-size: 12px;
			}

			& li{
				margin-left: 0px;
			}
		}

		
		& .navbar{
			 & .nav-right-custom{
			 	li {
					text-align: center;
					margin: 30px 0;		
				 }
			}
		}

		& .language-select{
			&>a{
				display: inline-block;
			}

			&>ul{
				display: inline-block;
			}
		}
	}
}

@media (max-width: 480px) {
	.header{
		& .header-contact{
			& li{
				display: block;
			}
		}

		& .list-contact{
			width: 100%;
		}
	}
}

.content{
	margin-bottom: 40px;

	& .content-dt{
		border: 1px solid #e1e1e1;
		padding: 30px;
		border-radius: 3px;

		& .gallery{
			& img{
			}
		}
	}

	& .ct-detail{
		& h3 {
			font-family: {{ $css['simple_font_bold'] }};
			font-size: 20px;
			margin-bottom: 20px;
		}
	}
}

@media (max-width: 769px) {
	.content-dt{
		margin-bottom: 20px;
	}
}

.content{
	& .content-contact{
		border: none;
		padding: 0;

		& .ct-detail{
			& h3{
				font-size: 30px;
				font-family: {{ $css['simple_font_black'] }};
				margin-top: 0;
			}

			& p{
				margin-bottom: 30px;
			}

			& .contact-info{
				margin-bottom: 30px;
				& li{
					font-size: 16px;
					color: #222222;
					font-family: {{ $css['simple_font_bold'] }};
					margin: 10px 0;

					& span{
						color: #909090;
						font-family: {{ $css['simple_font_italic'] }};
						width: 170px;
						font-size: 16px;
						display: inline-block;
					}
				}
			}

			& .contact-map{
				max-height: 540px;
				width: 100%;
			}
		}
	}
}

.content-info{
	& .ct-detail{
		& h3{
			margin-bottom: 20px;
		}
	}
}

footer {
	background-color: {{ $css['simple_bg_bottom_cl'] }};

	& p{
		font-size: {{ $css['simple_font_size_text_bt'] }};
		text-align: left;
		padding: 15px 0;
	}
}