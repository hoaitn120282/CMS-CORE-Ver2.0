@include(Theme::active().'.header')
@include(Theme::active().'.'.Theme::option('layouts','layout_style'))
@include(Theme::active().'.footer')

    
  
