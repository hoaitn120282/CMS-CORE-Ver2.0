@include(Theme::active().'.header')
@include(Theme::active().'.front-style1')
@include(Theme::active().'.footer')

    
  
