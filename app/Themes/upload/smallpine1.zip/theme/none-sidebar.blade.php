<div class="row">
	<div id="primary" class="content-area col-md-12">
		<main id="main" class="site-main" role="main">
			@yield('content')
		</main><!-- #main -->
	</div><!-- #primary -->
</div>
