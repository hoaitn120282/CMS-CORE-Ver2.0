<div id="primary" class="content-area col-md-8 col-md-offset-2">
	<main id="main" class="site-main" role="main">
		@yield('content')
	</main><!-- #main -->
</div><!-- #primary -->