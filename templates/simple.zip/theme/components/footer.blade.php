
<!--Begin Footer-->
<footer class="bg-top-bottom">
    <div class="container">
        <p class="">Powered by Sanmax #afsprakenbeheer.</p>
    </div>
</footer>
<!--End Footer-->

</body>
<script type="text/javascript" src="{{URL::to('/themes/simple')}}/js/plugin/jquery.min.js"></script>
<script type="text/javascript" src="{{URL::to('/themes/simple')}}/js/plugin/bootstrap.min.js"></script>
<script type="text/javascript" src="{{URL::to('/themes/simple')}}/js/plugin/lightslider.min.js"></script>
<script type="text/javascript" src="{{URL::to('/themes/simple')}}/js/plugin/jquery.appear.js"></script>
<script type="text/javascript" src="{{URL::to('/themes/simple')}}/js/plugin/owl.carousel.min.js"></script>

<script type="text/javascript" src="{{URL::to('/themes/simple')}}/js/main.js"></script>

</html>