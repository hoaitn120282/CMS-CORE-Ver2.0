<?php
/*
|--------------------------------------------------------------------------
| Config Theme Smallpine
|--------------------------------------------------------------------------
| require on config theme : 
| - name => @string
| - version => @string
| - author => @string
| - author_url => @string
| - description => @string
| - image_preview => @string
| - options => @array 
|   - name => @string
|   - type => imageupload | text | textarea | combobox
|   - *option => if type combobox else not require
|   - value => @string       
|   - label => @string
| - widget_position => @array
| - menu_position => @array
*/
return [
    /*
    *
    * General Theme
    *
    */
	'name' => 'simple',
    'version' => '1.0.0',
    'author' => 'ITLSVN',
    'author_url' => '#',
    'description' => 'Simple Theme',
    'image_preview' => 'preview.jpg',

    /*
    *
    * Set menu position on theme
    *
    */
    'menu_position' => ['menu-top','menu-bottom','menu-left','menu-right'],

    /*
    *
    * Set widget position on theme
    *
    */
    'widget_position' => ['post_slider','sidebar'],
    
    /*
    *
    * Set Theme Options
    *
    */
	"options"=>[
		"general"=>[
			[
				'name'=>'logo',
                'type'=>'imageupload',
                'value'=>'Default Theme',
                'label'=>'Logo',
            ],
			[
				'name'=>'feature_image',
                'type'=>'input_upload',
                'value'=>'http://sbd639.loc/uploads/hoangdv-log-checkout-240117.png',
                'label'=>'Feature image',
            ],
            [
				'name'=>'copyright',
                'type'=>'text',
                'value'=>'Copyright &copy; 2016 ITLSVN',
                'label'=>'Copyright Text',
            ],
            [
				'name'=>'customcss',
                'type'=>'textarea',
                'value'=>'',
                'label'=>'Custom CSS',
            ],
		],
		
		"social_media"=>[
			[
				'name'=>'facebook',
                'type'=>'text',
                'value'=>'',
                'label'=>'Facebook',
			],
			[
				'name'=>'twitter',
                'type'=>'text',
                'value'=>'',
                'label'=>'Twitter',
			],
			[
				'name'=>'google_plus',
                'type'=>'text',
                'value'=>'',
                'label'=>'Google Plus',
			],
			[
				'name'=>'youtube',
                'type'=>'text',
                'value'=>'',
                'label'=>'Youtube',
			],
		],
		
		"layouts"=>[
			[
				'name'=>'layout_style',
                'type'=>'combobox',
                'options'=>[
                    'right-sidebar'=>'Right Sidebar',
                    'left-sidebar'=>'Left Sidebar',
                    'none-sidebar'=>'None Sidebar',
                    'center-content'=>'Center Content',
                    'content'=>'Content',
                ],
                'value'=>'none-sidebar',
                'label'=>'Layout Style',
			]
		],
		/*
		 * Variable for build sass to css
		 * */
		'typography' => [
		    [
                'name' => 'simple',
                'label' => 'Config Typography',
                'type' => 'fieldset',
                'items' => [
                    [
                        'name'=>'color-black',
                        'value'=>'#222222',
                        'type' => 'colorpicker'
                    ],
                    [
                        'name'=>'text-position-cl',
                        'value'=>'#909090',
                        'type' => 'colorpicker'
                    ],[
                        'name'=>'btn-make-bg',
                        'value'=>'#f48100',
                        'type' => 'colorpicker'
                    ],[
                        'name'=>'font-black',
                        'value'=>'Raleway-Black',
                        'type' => 'combobox',
                        'options' => [
                            'Raleway-Black'=>'Raleway-Black'
                        ]
                    ],[
                        'name'=>'font-italic',
                        'value'=>'Raleway-Italic',
                        'type' => 'combobox',
                        'options' => [
                            'Raleway-Italic'=>'Raleway-Italic'
                        ]
                    ],[
                        'name'=>'bg-contact-cl',
                        'value'=>'#888888',
                        'type' => 'colorpicker'
                    ],[
                        'name'=>'section-title-cl',
                        'value'=>'#222222',
                        'type' => 'colorpicker'
                    ],[
                        'name'=>'background-menu-cl',
                        'value'=>'#999999',
                        'type' => 'colorpicker'
                    ],[
                        'name'=>'menu-text-cl',
                        'value'=>'#222222',
                        'type' => 'colorpicker'
                    ],[
                        'name'=>'menu-hover-cl',
                        'value'=>'#000000',
                        'type' => 'colorpicker'
                    ],[
                        'name'=>'bg-news-color',
                        'value'=>'#f6f6f6',
                        'type' => 'colorpicker'
                    ],[
                        'name'=>'bg-contact-top-color',
                        'value'=>'#c2c7d1',
                        'type' => 'colorpicker'
                    ],[
                        'name'=>'color-text-contact-top',
                        'value'=>'#ffffff',
                        'type' => 'colorpicker'
                    ],[
                        'name'=>'font-bold',
                        'value'=>'Raleway-Bold',
                        'type' => 'combobox',
                        'options'=>[
                            'Raleway-Bold'=>'Raleway-Bold'
                        ]
                    ],[
                        'name'=>'font-medium',
                        'value'=>'Raleway-Medium',
                        'type' => 'combobox',
                        'options'=>[
                            'Raleway-Medium'=>'Raleway-Medium'
                        ]
                    ],[
                        'name'=>'bg-bottom-cl',
                        'value'=>'#fafafa',
                        'type' => 'colorpicker'
                    ],[
                        'name'=>'font-size-text-bt',
                        'value'=>'12px',
                        'type' => 'colorpicker'
                    ]
                ]
            ],
		],
	]
];