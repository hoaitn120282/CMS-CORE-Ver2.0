@include(Theme::active().'.components.header')
{{--@include(Theme::active().'.'.Theme::option('layouts','layout_style'))--}}
@include(Theme::active().'.layouts.center-content'))
{{--@include(Theme::active().'.layouts.none-sidebar'))--}}
{{--@include(Theme::active().'.right-sidebar'))--}}
{{--@include(Theme::active().'.layouts.left-sidebar'))--}}
@include(Theme::active().'.components.footer')