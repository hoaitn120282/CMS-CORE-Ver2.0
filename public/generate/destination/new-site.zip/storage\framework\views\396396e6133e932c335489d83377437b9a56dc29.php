<div class="content"  >
	<div class="container">
		<div class="row">
			<div class="col-md-3 col-sm-12"><?php echo $__env->yieldContent('left-sidebar'); ?></div>
			<div class="col-md-6 col-sm-12"><?php echo $__env->yieldContent('content'); ?></div>
			<div class="col-md-3 col-sm-12"><?php echo $__env->yieldContent('right-sidebar'); ?></div>
		</div>
	</div>
</div>