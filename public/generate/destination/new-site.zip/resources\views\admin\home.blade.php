@extends('layouts.admin')

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">Administrator</div>

            <div class="panel-body">
                You are logged in ADmin!
            </div>
        </div>
    </div>
</div>
@endsection
