<?php
$config = [];

$config['active'] ='simple_1';
$config['active_extra'] ='simple_1';
$config['active_id'] ='3';
$config['driver'] ='file';

return $config;