<?php
$config = [];

$config['active'] ='clinic_medium';
$config['active_extra'] ='clinic_medium_kiki';
$config['active_id'] ='43';
$config['driver'] ='file';

return $config;