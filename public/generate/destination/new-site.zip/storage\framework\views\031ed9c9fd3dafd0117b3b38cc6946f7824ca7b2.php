<form method="POST" action="<?php echo e(($model != "") ? Admin::route('contentManager.post.update',['post'=>$model->id]) : Admin::route('contentManager.post.store')); ?>">
  <div class="col-md-9">
    <?php echo e(csrf_field()); ?>

    <?php if($model != ""): ?>
    <input name="_method" type="hidden" value="PUT">
    <?php $val = array() ?>
    <?php foreach($tags as $tag): ?>
      <?php if($tag->terms->taxonomy == "tag"): ?>
      <?php $val[] = $tag->terms->name ?>
      <?php endif; ?>
    <?php endforeach; ?>
    <?php endif; ?>
    <div class="form-group">
        <label for="title-post">Title Post</label>
        <input type="text" class="form-control" name="post_title" value="<?php echo e(($model != "" ) ? $model->post_title : old('post_title')); ?>" id="title-post" placeholder="Title Post">
        <?php if($model != ""): ?>
        <p class="help-block"><strong>Permalink : </strong><span id="slug-permalink"><?php echo e(Url('/')); ?>/<?php echo e($model->post_name); ?></span></p>
        <?php endif; ?>
    </div>
    <div class="form-group">
        <label for="content-post">Content</label>
        <textarea id="content-post" name="post_content" class="form-control" rows="18"><?php echo e(($model != "" ) ? Helper::bbcode($model->post_content) : old('post_content')); ?></textarea>
    </div>
    <div class="form-group">
        <label for="content-post">Post Excerpt</label>
        <textarea id="post-excerpt" name="post_excerpt" class="form-control" rows="5"><?php echo e(($model != "" ) ? $model->post_excerpt : old('post_excerpt')); ?></textarea>
    </div>
  </div>
  <div class="col-md-3">
    <div class="panel panel-default">
      <div class="panel-heading">Publish</div>
      <div class="panel-body">
        <button type="submit" class="btn btn-success btn-block"><?php echo e(($model != "" ) ? "Save Post" : "Publish Post"); ?></button> 
      </div>
      <ul class="list-group">
        <?php if($model != ""): ?>
        <li class="list-group-item"><i class="fa fa-calendar"></i> Create at : <?php echo e($model->created_at->format("d F Y")); ?></li>
        <li class="list-group-item"><i class="fa fa-calendar"></i> Update at : <?php echo e($model->updated_at->format("d F Y")); ?></li>
        <?php else: ?>
        <li class="list-group-item"><i class="fa fa-calendar"></i> Create at : <?php echo e(date("d F Y")); ?></li>
        <?php endif; ?>
        <li class="list-group-item"><i class="fa fa-user"></i> Author : <?php echo e(Auth::guard('admin')->user()->name); ?></li>
        <?php if($model != ""): ?>
        <li class="list-group-item">
          <select name="status" class="form-control">
            <option <?php echo e(($model->post_status == "publish") ? "selected" : ""); ?> value="publish">Publish</option>
            <option <?php echo e(($model->post_status == "Draft") ? "selected" : ""); ?> value="Draft">Draft</option>
          </select>
        </li>
        <?php else: ?>
        <li class="list-group-item">
          <select name="status" class="form-control">
            <option value="publish">Publish</option>
            <option value="Draft">Draft</option>
          </select>
        </li>
        <?php endif; ?> 
        <?php if($model != ""): ?>
        <li class="list-group-item">
          <select name="comment_status" class="form-control">
            <option <?php echo e(($model->comment_status == "open") ? "selected" : ""); ?> value="open">Open Comment</option>
            <option <?php echo e(($model->comment_status == "close") ? "selected" : ""); ?> value="close">Close Comment</option>
          </select>
        </li>
        <?php else: ?>
        <li class="list-group-item">
          <select name="comment_status" class="form-control">
            <option value="open">Open Comment</option>
            <option value="close">Close Comment</option>
          </select>
        </li>
        <?php endif; ?>         
      </ul>
    </div>
    <div class="featured-post">
      <label>
        <div class="labelFeaturedPost">
        Featured Post 
        </div>
          <input type="checkbox" class="js-switch" name="meta[featured_post]" <?php echo e(($model != "" ) ? ($model->getMetaValue('featured_post') ? "checked" : ""  ) : old('meta[featured_img]')); ?> /> 
      </label>
      <div class="clearfix"></div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">Categories</div>
      <div class="panel-body list-category">
         <ul id="parent-0" class="list-unstyled category-list-scroll">
            <?php foreach($category as $node): ?>
                <?php if(count($node->children()) > 0 ): ?>
                  <?php echo $__env->make('ContentManager::post.partials.categorylist', ['datas' => $node->children(),'post'=>($model != "" ) ? $model->id : false], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
                <?php endif; ?>
            <?php endforeach; ?>
        </ul>
        <a id="btn-add-category" class="btn btn-success btn-sm btn-block" href="#"> + Add Category</a>
        <div id="input-category">
           <div class="form-group">
            <label for="name-category">Name Category</label>
            <input type="text" class="form-control" id="name-category" placeholder="Name Category">
          </div>
          <div class="form-group">
            <label for="parent-category">Parent</label>
            <select class="form-control" id="parent-category">
              <option value="0">Select Parent</option>
                  <?php foreach($category as $node): ?>
                    <?php if(count($node->children()) > 0 ): ?>
                      <?php echo $__env->make('ContentManager::partials.categoryoption', ['datas' => $node->children(),'select'=>($model != "" ) ? $model->parent : 0], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
                    <?php endif; ?>
                  <?php endforeach; ?>
            </select>
          </div>
          <a href="#" id="add-category" class="btn btn-default btn-sm">Add Category</a>
        </div>
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">Tags</div>
      <div class="panel-body">
        <input type="text" class="form-control" name="tags" id="tags" value="<?php echo e(($model != "" ) ? implode(',',$val) : old('tags')); ?>" data-role="tagsinput" >
      </div>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading">Featured Image</div>
      <div class="panel-body">
        <?php echo $__env->make('ContentManager::partials.inputBtnUpload',['idModal'=>'featuredImage','setInput'=>'meta_featured_img'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
      </div>
    </div>
  </div>
</form>





