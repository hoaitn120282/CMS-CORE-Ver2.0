<?php

return [
    'default_role' => 1,
];
