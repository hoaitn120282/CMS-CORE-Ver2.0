
<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta content="text/html;charset=utf-8" http-equiv="Content-Type">
    <meta content="utf-8" http-equiv="encoding">
    <meta name="viewport" content="width=device-width,  initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <link rel="icon" href="img/favicon.ico" type="image/x-icon" />

    <link rel="stylesheet" href="<?php echo e(URL::to('/themes/clinic_medium')); ?>/css/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(URL::to('/themes/clinic_medium')); ?>/css/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(URL::to('/themes/clinic_medium')); ?>/css/owl.carousel/dist/assets/owl.carousel.min.css" />
    
    <?php
		$css_name = Theme::strActiveExtra().".css";
		$css_path = "themes/clinic_medium/css/{$css_name}";
		$css_file = public_path($css_path);
	?>
	<?php if(File::exists($css_file)): ?>
		<link rel="stylesheet" href="<?php echo e(asset($css_path)); ?>">
	<?php else: ?>
		<link rel="stylesheet" href="<?php echo e(URL::to('/themes/clinic_medium')); ?>/css/main.css">
	<?php endif; ?>
    
</head>
<title>Medium Site Title</title>
<body>

    <!-- Header -->
    <?php echo $__env->make(Theme::active().'.components.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /.Header -->

    <!--Begin Content-->
    <div class="content">
        <?php /*<?php echo $__env->make(Theme::active().'.'.Theme::option('layouts','layout_style'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>*/ ?>
        <?php echo $__env->make(Theme::active().'.layouts.none-sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>)
    </div>
    <!--End Content-->

    <!--Begin Footer-->
    <?php echo $__env->make(Theme::active().'.components.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--End Footer-->

</body>

<script type="text/javascript" src="<?php echo e(URL::to('/themes/clinic_medium')); ?>/js/plugin/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo e(URL::to('/themes/clinic_medium')); ?>/js/plugin/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo e(URL::to('/themes/clinic_medium')); ?>/js/plugin/jquery.appear.js"></script>
<script type="text/javascript" src="<?php echo e(URL::to('/themes/clinic_medium')); ?>/js/plugin/owl.carousel.min.js"></script>

<script type="text/javascript" src="<?php echo e(URL::to('/themes/clinic_medium')); ?>/js/main.js"></script>

</html>