<form  method="POST" action="<?php echo e(($model != "") ? Admin::route('contentManager.category.update',['category'=>$model->term_id]) : Admin::route('contentManager.category.store')); ?>">
  <?php echo e(csrf_field()); ?>

  <?php if($model != ""): ?>
  <input name="_method" type="hidden" value="PUT">
  <?php endif; ?>
  <div class="form-group">
    <label for="name-category">Name *</label>
    <input type="text" class="form-control" value="<?php echo e(($model != "" ) ? $model->name : old('name')); ?>" name="name" id="name-category" placeholder="Name Category">
  </div>
  <div class="form-group">
    <label for="slug-category">Slug</label>
    <input type="text" class="form-control" value="<?php echo e(($model != "" ) ? $model->slug : old('slug')); ?>" name="slug" id="slug-category" placeholder="Slug Category">
  </div>
  <div class="form-group">
    <label for="parent-category">parent</label>
    <select class="form-control"  name="parent" id="parent-category">
      <option value="0">Select Parent</option>
          <?php foreach($category as $node): ?>
            <?php if(count($node->children()) > 0 ): ?>
              <?php echo $__env->make('ContentManager::partials.categoryoption', ['datas' => $node->children(),'select'=>($model != "" ) ? $model->parent : 0], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
            <?php endif; ?>
          <?php endforeach; ?>
    </select>
  </div>
  <div class="form-group">
    <label for="desctiption-category">Description</label>
    <textarea class="form-control" name="description" rows="3"><?php echo e(($model != "" ) ? $model->description : old('description')); ?></textarea>
  </div>
  <?php if($model != ""): ?>
  <button type="submit" class="btn btn-default">Save</button>
  <a href="<?php echo e(Admin::route('contentManager.category.index')); ?>" class="btn btn-warning">Cencel</a>
  <?php else: ?>
  <button type="submit" class="btn btn-default">Create</button>
  <?php endif; ?>
</form>

