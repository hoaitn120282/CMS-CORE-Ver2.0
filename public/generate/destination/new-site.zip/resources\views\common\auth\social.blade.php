<div class="social-button-group text-center">
	<a class="social-button button-facebook" data-toggle="tooltip" data-placement="top" title="Login with Facebook" href="{!! route('auth.social', ['driver' => 'facebook']) !!}"><i class="fa fa-facebook"></i></a>
	<a class="social-button button-google" data-toggle="tooltip" data-placement="top" title="Login with Google" href="{!! route('auth.social', ['driver' => 'google']) !!}"><i class="fa fa-google"></i></a>
	<a class="social-button button-github" data-toggle="tooltip" data-placement="top" title="Login with Github" href="{!! route('auth.social', ['driver' => 'github']) !!}"><i class="fa fa-github"></i></a>
	<a class="social-button button-twitter" data-toggle="tooltip" data-placement="top" title="Login with Twitter" href="{!! route('auth.social', ['driver' => 'twitter']) !!}"><i class="fa fa-twitter"></i></a>
	<a class="social-button button-linkedin" data-toggle="tooltip" data-placement="top" title="Login with LinkedIn" href="{!! route('auth.social', ['driver' => 'linkedin']) !!}"><i class="fa fa-linkedin"></i></a>
</div>
