<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
    <?php echo $__env->make('ContentManager::partials.errormessage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <div class="col-md-4">
	  <?php echo $__env->make('ContentManager::category.partials.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </div>
  <div class="col-md-8">
    <?php echo $__env->make('ContentManager::category.partials.tablemanage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php echo $__env->make('ContentManager::partials.scriptdelete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>