<div class="search-no-result">
    <h2>{{$message}}</h2>
</div>