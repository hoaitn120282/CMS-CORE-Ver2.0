<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="x_panel">
          <div class="x_title">
            <h2>Theme <?php echo e(ucfirst($model->name)); ?></h2>
            <ul class="nav navbar-right panel_toolbox">
              	<?php if($model->status): ?>
              	<li><a href="#" onclick="return false;">Actived</a></li>
              	<?php else: ?>
				<li><a href="<?php echo e(Admin::route('contentManager.theme.active', ['id'=>$model->id])); ?>" style="background-color:#449d44;color:#fff;padding-left:20px;padding-right:20px">Active</a></li>
              	<?php endif; ?>
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
          	<?php if(Session::has('success')): ?>
			  <div class="alert alert-success" role="alert">
			    <?php echo e(Session::get('success')); ?>

			  </div>
			<?php endif; ?>
             <div class="row">
				<div class="col-md-4">
					<img style="width: 100%; display: block;" src="<?php echo e(url('/themes/'.$model->name)); ?>/images/<?php echo e($model->image_preview); ?>" alt="image">
				</div>
				<div class="col-md-8">
					<dl>
						<dt>Name Theme</dt>
						<dd><?php echo e($model->name); ?></dd>
						<dt>Author Theme</dt>
						<dd><a href="<?php echo e($model->author_url); ?>"><?php echo e($model->author); ?></a></dd>
						<dt>Description</dt>
						<dd><?php echo e($model->description); ?></dd>
					</dl>
				</div>
				<div class="col-md-12">
					<div class="x_panel">
	                  <div class="x_title">
	                    <h2>Theme Options</h2>
	                    <ul class="nav navbar-right panel_toolbox">
	                    	<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
	                      <li><a class="close-link"><i class="fa fa-close"></i></a>
	                      </li>
	                    </ul>
	                    <div class="clearfix"></div>
	                  </div>
	                  <div class="x_content">

	                    <div class="col-xs-3">
	                      <ul class="nav nav-tabs tabs-left">
	                      	<?php foreach($model->metaOptions() as $key => $meta): ?>
	                      		<?php if($key == 0): ?>
	                      		<li class="active"><a href="#tab-<?php echo e($meta->meta_key); ?>" data-toggle="tab"><?php echo e(ucwords(str_replace("_", " ", $meta->meta_key))); ?></a></li>
	                      		<?php else: ?>
								<li><a href="#tab-<?php echo e($meta->meta_key); ?>" data-toggle="tab"><?php echo e(ucwords(str_replace("_", " ", $meta->meta_key))); ?></a></li>
								<?php endif; ?>
							<?php endforeach; ?>
	                      </ul>
	                    </div>
						<form method="POST" action="<?php echo e(Admin::route('contentManager.theme.update')); ?>">
						<?php echo e(csrf_field()); ?>

						<input type="hidden" value="<?php echo e($model->id); ?>" name="idtheme">
	                    <div class="col-xs-9">
	                      <!-- Tab panes -->
	                      <div class="tab-content">
	                        <?php foreach($model->metaOptions() as $key => $meta): ?>
								 <?php echo $__env->make('ContentManager::theme.partials.generate', ['meta' => $meta], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							<?php endforeach; ?>
	                      </div>
	                      <input type="submit" class="btn btn-success" value="Save">
	                    </div>
						</form>
	                    <div class="clearfix"></div>
	                  </div>
	                </div>
				</div>
             </div>
          </div>
        </div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(Admin::theme(), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>