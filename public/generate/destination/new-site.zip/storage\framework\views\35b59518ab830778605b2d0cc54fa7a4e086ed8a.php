<div class="container">
	<div class="row">
		<?php /*<div class="col-md-3">*/ ?><?php /*<?php echo e(Widget::group('sidebar')); ?>*/ ?><?php /*</div>*/ ?>
		<div class="col-md-3 col-sm-12"><?php echo $__env->yieldContent('sidebar'); ?></div>
		<div class="col-md-9 col-sm-12"><?php echo $__env->yieldContent('content'); ?></div>
	</div>
</div>