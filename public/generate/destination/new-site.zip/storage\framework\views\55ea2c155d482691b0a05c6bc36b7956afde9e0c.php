<option <?php echo e(($node->term_id == $select) ? "selected" : ""); ?> value="<?php echo e($node->term_id); ?>"><?php echo e($node->name); ?></option>
<?php if(count($datas->get()) > 0 ): ?>
	<?php foreach($datas->get() as $node): ?>
	<?php echo $__env->make('ContentManager::partials.categoryoption', ['datas' => $node->children(),'select'=>$select], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endforeach; ?>
<?php endif; ?>
