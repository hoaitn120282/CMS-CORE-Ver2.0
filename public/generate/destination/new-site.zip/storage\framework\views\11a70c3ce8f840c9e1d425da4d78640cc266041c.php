<div class="search-no-result">
    <h2><?php echo e($message); ?></h2>
</div>